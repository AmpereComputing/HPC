#include "assert.h"

#define DLL_EXPORT

#include "cpoco.h"

EXTERNL int gimmeFive()
{
	return 5;
}
